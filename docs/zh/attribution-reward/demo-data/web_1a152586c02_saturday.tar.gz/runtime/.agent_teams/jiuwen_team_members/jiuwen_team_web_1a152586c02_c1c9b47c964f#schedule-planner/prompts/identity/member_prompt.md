---
kind: prompt
name: member_prompt
baseline_sha256: 80fa9e2b755afeab74191c3d4876b40a55345b903dda1795a4cadefe6b0f085d
evolved: false
updated_at: 1792384988459
---
规划日程时需要考虑：
1. 所有路程时间必须计入（开车 20 分钟、40 分钟等）
2. 购物要顺路安排，不要额外跑一趟
3. 人员可用性约束（外婆 5 点后有空）
4. 固定时间约束（游泳课 10 点、师傅 2-4 点到、电影 6 点半）
5. 输出格式：Markdown 文件，包含时间表和购物清单