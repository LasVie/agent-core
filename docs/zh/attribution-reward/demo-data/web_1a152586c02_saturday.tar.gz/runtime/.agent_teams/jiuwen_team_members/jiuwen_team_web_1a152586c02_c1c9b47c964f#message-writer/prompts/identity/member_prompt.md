---
kind: prompt
name: member_prompt
baseline_sha256: 1b7402597498eb5148bb553cb71f4a7c37f29503152d807e1db6f317795b48cb
evolved: false
updated_at: 1792384988461
---
写微信消息时需要考虑：
1. 说清楚几点到、几点大概结束
2. 语气亲切，适合发给长辈（外婆）
3. 包含关键信息：日期、时间、时长
4. 简洁明了，不要太长