---
kind: tool
name: checkpoint
language: cn
baseline_sha256: 8e48d1e038b1a0ab4e831dcb773ee719b0eb165af17bd46138c8471ba648135f
evolved: false
updated_at: 1792382889838
---
为本成员当前对话上下文保存一个命名快照。后续 `spawn_teammate(fork="此名称")` 即可让新成员继承该快照的上下文，无需重新读取文件和搜索代码。

| 参数 | 说明 |
|---|---|
| **name** | 快照名（语义化 slug，如 `code-ready`、`base-class-understood`）。后续 fork 通过此名引用 |
| **description** | 可选；为何在此处打快照（如「基类接口分析完成」），仅用于日志和调试 |

## 何时使用

当本成员完成了**可复用的阶段性工作**后调用——例如：

- 阅读了基类/接口源码，后续多个执行者需要基于此实现不同派生类
- 分析了项目整体架构，后续执行者需要直接在代码理解基础上开工
- 完成了一份关键代码的调研，希望多个成员继承这份上下文

调用后继续工作不受影响——快照保存的是调用时刻的上下文位置。多个成员可以共享同一份快照。

## 示例

```
理解者完成基类阅读后：
checkpoint(name="base-ready", description="基类接口分析完成，可 fork")
```

## 快照名唯一性

快照名在整个团队内**唯一**：一旦某成员保存了某个名字，其他成员不能再复用。重名调用会被**拒绝**，错误信息会指出已占用快照的创建者与用途——你既可以换个名字，也可以直接 fork 已有快照（如果它已经涵盖你需要的上下文）。

## 与 fork 配合

```python
# 1. 理解者打快照
checkpoint(name="code-ready")

# 2. Leader 从快照 fork 多个执行者
spawn_teammate(name="dev-1", fork="code-ready", fork_source="understander", ...)
spawn_teammate(name="dev-2", fork="code-ready", fork_source="understander", ...)
```

**快照存的是调用时刻此成员的 `len(messages)`**。之后上下文继续增长不会影响已存快照的语义——fork 从该位置截取，后续消息不在继承范围内。

## 告知 Leader

打完快照后，运行时**会自动通知 leader**——发布框架事件，leader 上下文会收到一条带确切快照名的 announcement-only 公告（明示不需要回复）。你**无需**再单独用 `send_message` 汇报名字；想让 leader 理解快照用途，就把说明写进 `description` 参数（会随公告一起带上）。leader 随时可用 `list_checkpoints` 查看权威清单——不要指望 leader 猜你起的名字。

## Fork 模式

leader 从你的快照 fork 时，`spawn_teammate(fork="<name>", fork_mode=...)` 决定继承什么：`before`（默认，保留到快照为止的分析）、`after`、`keep_before_compact_after`、`keep_after_compact_before`。快照本身始终只是一个位置标记——模式由 leader 在 fork 时选择，不固化在快照里。