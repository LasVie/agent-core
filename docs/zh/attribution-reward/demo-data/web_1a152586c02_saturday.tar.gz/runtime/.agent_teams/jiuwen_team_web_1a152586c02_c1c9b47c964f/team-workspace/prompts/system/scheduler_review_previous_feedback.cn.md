---
kind: prompt
name: scheduler_review_previous_feedback
language: cn
baseline_sha256: badeb8d25d87bac62ab55849c45e09a8ea3823bb1cd72dde18666ddd5ab2548f
evolved: false
updated_at: 1792382889810
---
## 你上一轮（第 {{vote.review_round}} 轮）的验收意见

- 投票：{{vote.decision}}
- 意见：{{vote.feedback}}

本轮请先逐条核对上述问题是否已修复，再按下方验收标准完整验收，不要只复核旧问题。