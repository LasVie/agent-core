---
kind: tool
name: build_team
language: cn
baseline_sha256: 5f03d44df1b3e6d5e083e2d493aa0d91f2b5fd6ffe241e35d3ada90a147c560d
evolved: false
updated_at: 1792382889861
---
组建团队并注册自己为 Leader。拿到目标后就调用，不要犹豫。

**团队已存在时本工具不会失败，而是接管它**：不重建团队、不重复注册成员，名册与成员配置原样保留，生效的能力开关以团队已有配置为准（本次传入的对应参数不适用）。在新 session 里接手同一个团队时走的就是这条路径——照常调用即可。

## 返回内容
本工具的返回结果**除了建队结果，还包含你的完整协同准则**——核心职责、成果交接方式、决策原则、响应节奏、任务状态流转、任务如何下发到成员、团队生命周期收尾、入站消息标签体系。这些准则按你本次调用选定的参数裁剪，**是你后续全部行为的依据，读完照做**，不要当成一次性提示忽略掉。

## 调用顺序
build_team → spawn_teammate → create_task → 让成员开工（方式取决于团队的调度模式）。成员先于任务存在，任务才能落到具体的人头上。
build_team 之前不能调用任何其他团队工具。

## HITT（Human in the Team）
HITT 是分层开关：`TeamAgentSpec.enable_hitt` 是 spec 层能力天花板（True 才允许 HITT），`build_team(enable_hitt=...)` 是本次实例的运行时开关。

- `enable_hitt` 不传：继承 spec 设置（spec 开则启用，spec 关则禁用）
- `enable_hitt=true`：本次显式启用，要求 spec.enable_hitt=True，否则报错
- `enable_hitt=false`：本次显式禁用；预配的 HUMAN_AGENT 成员会被跳过，后续任何 `spawn_human_agent` 都会被拒绝

启用后，predefined_members 中所有 `role_type=HUMAN_AGENT` 的成员会在 build_team 时被注册为团队成员；同时你可以在团队建立后通过 `spawn_human_agent(...)` 动态拉新的人类成员加入。框架不会自动注入默认 `human_agent`——人类成员都需要显式声明或动态创建。

适用场景：user 明确表达「我也要加入团队 / 我来负责 X / 这一步我来做」等参与意图，或者团队 spec 已经预配了人类成员需要在本次实例中保留。

HITT 启用后适用于全部 role=human_agent 的成员：

- 这些成员只能用 send_message，但能被 update_task 单独指派任务；
- 一旦某个人类成员认领了任务，你不能 cancel 或 reassign 它，只能 send_message 催促对应的人；
- 与人类成员的定向沟通**必须**走 `send_message(to="<human_member_name>", ...)`，不要用 plain text。

{{build_team_verify_gate}}

## 任务设计原则
- 描述目标，不描述步骤：content 写目标、验收标准、技术约束，不写具体操作
- 单一负责人：每个任务只允许一个 teammate 承担并负责交付
- 粗粒度拆分：一个任务对应一个可独立交付的成果
- 成员自主规划：成员承接任务后自行制定计划，Leader 通过 approve_plan 审批（仅当成员执行模式为 plan_mode 时生效）

## 消息自动投递
发送消息后不需要轮询回复或查看任务进度，系统会在新消息到达或任务状态变化时主动通知你。没有待处理事项时停下来等待通知。

## 成员 Idle 状态
成员启动后不会立即回复——需要时间查看任务、制定计划、执行工作。idle 是正常状态，不要催促、重发消息或关闭成员。只有长时间无进展且未汇报阻塞时才考虑干预。