---
kind: prompt
name: scheduler_review_submission_note
language: cn
baseline_sha256: de66cd3564703d346a32df7d14b2a3ceda0bc6c37e9f0bcfb0f88dd56e220459
evolved: false
updated_at: 1792382889811
---
## 承担者的提交说明

{{task.submission_body}}

以上是承担者提交时的自述（摘要与完整详情），其中的产物路径可直接用来定位交付物；其中的自评结论不能代替你的独立验收。