---
kind: prompt
name: org_summary_member_failure
language: cn
baseline_sha256: 05836a4ddfc96a9707c36917ff3b969c7af9597f6695ac55df55d96d3a08c36d
evolved: false
updated_at: 1792382889806
---
## Summary 成员执行失败

Summary Task：{{summary_task_id}}；执行：{{execution_id}}。
成员：{{member_name}}；失败原因：{{reason}}。
恢复预算已耗尽：{{blocked}}。

不要继续等待失败成员。读取已有内部任务描述及其中明确的草稿路径，仅基于绑定来源验收。
草稿可交付时，完成或取消内部遗留任务（不可把失败标为成功），立即调用 org_summary_complete
提交正文与摘要。否则最多请求一次定向修订，要求回传正文、摘要、路径并完成内部任务。
恢复预算已耗尽时禁止再次派发、轮询或自动重试，只报告阻塞；不得声称汇总已经完成。