---
kind: prompt
name: scheduler_review_renudge
language: cn
baseline_sha256: 24934dced57d8740ce9a8d0682fde813fa227993054f988d2d3bbb0cd11c2206
evolved: false
updated_at: 1792382889810
---
[验收催办] 任务 [{{task.task_id}}]「{{task.title}}」第 {{task.review_round}} 轮验收仍在等待你的投票。

## 任务目标与验收标准

{{task.content}}

请尽快调用 `verify_task(task_id='{{task.task_id}}', decision='pass'|'fail')` 完成投票。