---
kind: tool
name: send_message_scheduled
language: cn
baseline_sha256: 01a315d30947d045565c7a9b62ef3c896215ed118386df670a61a6bc3f6b4d63
evolved: false
updated_at: 1792382889848
---
向 Leader 汇报，或回复用户。用于同步需要 Leader 知道或决定的事项、升级阻塞问题、请求改派任务。完成情况由任务的 `summary` / `note` 交接，**不要**用本工具汇报完成或送审。

本团队运行在**调度指派模式**：你不与其他成员直接通信。协作需求一律经 Leader 转达。

| `to` 值 | 含义 |
|---|---|
| `"leader"` | 向 Leader 汇报（点对点）。这是**角色名**，不是具体成员名——系统会自动投递给真正的 Leader。需要它知道或决定的事项、阻塞、改派请求都发给它 |
| `"user"` | 当收到的消息来源（`from`）为 `user` 时，必须用本工具把答复发回 `user` —— 你的普通文本输出不会送达用户 |

**你不能发给其他成员、不能多播、不能广播。**需要其他成员配合时，把需求告诉 Leader，由它协调或改派任务。

{{artifact_handoff_policy}}

你的普通文本输出对 Leader 和用户都不可见 —— 要通信必须调用此工具。来自 Leader 的消息会自动送达，无需轮询。用名称称呼成员，不要使用内部 ID。