---
kind: prompt
name: scheduler_rework_summary
language: cn
baseline_sha256: bf21b863b832a4c155e14b4915f25b18bafe21f8532bdb7a174584dac9fce797
evolved: false
updated_at: 1792382889812
---
[验收卡死·升级] 任务 [{{task.task_id}}]「{{task.title}}」已超过最大验收轮数（{{param.max_rounds}}），不再自动返工，已提交 leader 处置。

## 你需要做的

请用 `send_message(to='leader', ...)` 向 leader 发送一份返工总结，覆盖以下内容：

1. **你做了哪些修改尝试** — 每轮修复了什么、采纳了什么反馈
2. **为什么一直未能通过** — 你认为卡在哪一个验证点上
3. **遇到什么阻塞或困难** — 需求不清、技术限制、上下文缺失等

Leader 会综合你的总结和验证者反馈，决定下一步方向（继续修复、更换承担者、调整需求或取消任务）。