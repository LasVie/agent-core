---
kind: tool
name: view_task_scheduled
language: cn
baseline_sha256: 58378015502c2169e1356ae7a069f8481e9eb85c331ce7a655612ed2976935a6
evolved: false
updated_at: 1792382889861
---
查看团队任务信息。

**约束**: 任务状态变化（新建、开工、完成、指派、解锁、验证结论等）会即时推送给你，禁止反复调用本工具轮询进度。本团队运行在**调度指派模式**：任务由调度框架指派并通知你开工，**不要用本工具找活儿**。

## 使用场景

### action=list（默认，零参数调用）
- 查看所有任务的整体进度、识别被阻塞的任务和瓶颈
- 了解其他成员各自在做什么

### action=get（需要 task_id）
- 查看**其他成员**任务的内容与完成说明（note）——例如你的下游需要你交付什么、上游交付了什么
- 开工通知已包含你自己任务的目标、验收标准与上下游简述，通常不需要再 get 自己的任务

### action=note（需要 task_id）
- 读取某个任务完整的完成摘要（summary）与完成详情（note）——看板摘要、上游列表里的完成摘要只是截断的一行

### action=in_review
- 你是验证者时，列出等待你验收的任务

## 输出

### list
每个任务的摘要：task_id, title, status, assignee, blocked_by。
不含 content — 需要详情请用 action=get 查看单个任务。

### get
单个任务完整详情：含 content、summary / note（承担者的完成摘要与详情）、blocked_by（前置依赖）、blocks（下游依赖）。

### note
单个任务的完成摘要（summary）与完整完成详情（note），不截断。

## Tips

- list 不返回 content，token 开销低。需要详情时再 get 单个任务。
- 任务的开始、验收与交接都由调度框架完成；本工具只用来**看**，不用来决定下一步做什么。