---
kind: tool
name: view_task_reviewer
language: cn
baseline_sha256: 5d6de70dad2098281798c29e8e00b25144a392d65a6146ffdaacd3ae57e9e4c7
evolved: false
updated_at: 1792382889859
---
查看团队任务信息（验收兜底用）。

**约束**: 验收请求已经包含被验收任务的完整信息——任务内容与验收标准、上游任务及其完成摘要、承担者的提交说明（摘要与完整详情）、你上一轮的验收意见。上游任务的完整完成详情需要时用 `action=note` 读取。**不要**为了"再看一遍任务详情"调用本工具。

## 使用场景

只在验收请求中的信息互相矛盾或明显缺失、无法据此完成验收时使用：

### action=get（需要 task_id）
- 读取任务当前的内容、完成说明（note）与上下游依赖

### action=note（需要 task_id）
- 读取某个任务完整的完成摘要（summary）与完成详情（note）——看板摘要、上游列表里的完成摘要只是截断的一行

### action=list
- 查看看板上各任务的摘要（不含 content）

## 输出

### get
单个任务完整详情：含 content、summary / note（承担者的完成摘要与详情）、blocked_by（前置依赖）、blocks（下游依赖）。

### note
单个任务的完成摘要（summary）与完整完成详情（note），不截断。

### list
每个任务的摘要：task_id, title, status, assignee, blocked_by。