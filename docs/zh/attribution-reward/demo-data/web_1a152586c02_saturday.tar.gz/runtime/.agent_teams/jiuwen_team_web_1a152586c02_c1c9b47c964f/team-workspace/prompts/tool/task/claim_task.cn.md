---
kind: tool
name: claim_task
language: cn
baseline_sha256: 429fb4580de16472bab336eec44c6530c7df6c91515f5ad9305631c3cddd76f4
evolved: false
updated_at: 1792382889850
---
领取或完成任务（仅 Teammate 可用）。

## 使用场景

**领取任务开始工作：**
- 从 view_task 中找到 pending 且无人认领的任务后，设置 status=claimed 领取
- 应选择匹配自己领域专长的任务
- **同一时刻只能有一个进行中（in_progress）的任务**：若你已有认领在做的任务，需先完成它再领取新任务，否则领取会被拒绝
- 领取成功后，结果会列出本任务直接上游的交付摘要；需要某个上游的完整说明时用 `view_task(action='note', task_id=...)`

**标记任务完成：**
- 完成任务描述的所有工作后，设置 status=completed 标记完成，同时填写：
  - `summary`：一句话完成摘要——交付了什么、主产物在哪。Leader 与下游看到的就是它
  - `note`：完整的完成详情——产物路径、关键决策或后续注意事项
- `summary` / `note` 就是你的完成交接，完成后**不要**再用 send_message 汇报完成；二者只在 status=completed 时生效
- 重要：完成后应调用 view_task 寻找下一个可用任务

- 只有在完全完成任务后才能标记 completed
- 如果遇到错误、阻塞或无法完成，保持任务为 in_progress 状态
- 被阻塞时，通过 send_message 通知 leader
- 认领任务后若长时间无法完成，应及时通过 send_message 与 leader 沟通，调整任务范围或拆分任务
- 以下情况不得标记 completed：
  - 测试未通过
  - 实现不完整
  - 遇到未解决的错误

## 状态流转

`pending` → `in_progress` → `completed`

## 过期检查

更新前应通过 view_task(action=get) 获取任务最新状态。

## 示例

领取任务：
{"task_id": "task-1", "status": "claimed"}

完成任务：
{"task_id": "task-1", "status": "completed", "summary": "登录接口已实现，代码在 src/auth/login.py", "note": "使用 JWT，过期 2 小时；单测在 tests/test_login.py，全部通过"}