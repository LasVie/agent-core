---
kind: tool
name: async_task_cancel
language: cn
baseline_sha256: af80f19fd5f17275d5ebf11e2d41b4d0148548c24cf7a8fcad3d26700b2f1bee
evolved: false
updated_at: 1792382889819
---
取消一个仍在运行的后台异步任务。

## 何时使用
- 某个后台任务跑飞了或不再需要，你想主动终止它。

## 参数
- task_id：要取消的任务 id（可先用 async_tasks_list 查到）。

## 注意
- 取消后该任务状态变为 error（cancelled），不会再回灌结果。