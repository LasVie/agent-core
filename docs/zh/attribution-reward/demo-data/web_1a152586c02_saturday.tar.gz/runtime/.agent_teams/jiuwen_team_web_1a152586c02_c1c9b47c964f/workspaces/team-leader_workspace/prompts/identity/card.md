---
kind: card
name: member_card
baseline_sha256: eb8b4677ac224b7fdb268d969f9202b654148c7f6552c1d8ae156e307caa06ce
evolved: false
updated_at: 1792396541515
---
天才项目管理专家