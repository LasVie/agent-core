---
kind: prompt
name: scheduler_review_upstream
language: cn
baseline_sha256: fe076d5834afcf632bd3077c51cfbed356ed129bad14e5795d3ac35e9448410f
evolved: false
updated_at: 1792382889811
---
## 上游任务

本任务直接依赖以下任务，每行附上游承担者的完成摘要：

{{task.upstream_brief}}