---
kind: tool
name: async_tasks_list
language: cn
baseline_sha256: 64cfac3f0be43c3ad13d3fa799e5ede8eee50d66d16abf890feb7b03ed4b335c
evolved: false
updated_at: 1792382889821
---
列出当前 harness 上的所有后台异步任务及其状态。

## 何时使用
- 你想查看已启动的后台任务清单及各自的运行/完成/失败状态；
- 你不确定某个后台任务是否还在运行。

## 输出
每行一个任务：task_id、工具名、状态（running/completed/error）、描述。

## 注意
- 后台任务完成后结果会**自动回灌**给你，**无需轮询**本工具等待完成。
- 仅当你需要主动概览或定位某个 task_id 时才调用。