---
kind: tool
name: update_task_verify_gate
language: cn
baseline_sha256: 329c997666ea1a5470a886216390e90208f49e99893f4bee72d813ff14179224
evolved: false
updated_at: 1792382889834
---
**设置 / 清除验证闸：**
- 传 reviewer（结构化对象数组）给任务指派验证者，任何状态下都可以设或改；传空数组清除验证闸
- 验证者不能是该任务的 assignee 本人（不允许自验）
- 配了验证者的任务，承担者完成后进入 in_review 等裁决，调度框架会自动唤起验证者，你不需要手动催办
- max_review_rounds 限制返工轮数上限（≥1），只对已配或本次同时配 reviewer 的任务有意义；轮数耗尽仍未通过时升级给你决策
- 验证者的类型与 instruction 怎么写，见系统提示词《任务下发与获取》一节