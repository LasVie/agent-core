---
kind: tool
name: set_member_model
language: cn
baseline_sha256: f0f25671bf625e5cb46e42c81fb8aa0ab4baa39943b70599e263cd64b38599fc
evolved: false
updated_at: 1792382889840
---
把一个外部 CLI 成员（claudecode / codex 等）切换到另一个内置模型，或调整其推理强度，无需重新拉起。内置模型使用 CLI 自身登录（如订阅）运行；可选的模型与强度列在 `<builtin_model_catalog>` 中（见 `model` 参数）。

| 参数 | 用法 |
|---|---|
| **member_name** | **必填**。要切换的外部 CLI 成员 |
| **model** | 可选。从该成员 `cli_agent` 对应的目录条目中选择模型。省略时保持当前模型，只调整 `effort` |
| **effort** | 可选。所选模型的 `efforts` 之一。指定了 `model` 而省略时取该模型的 `default_effort`；未指定 `model` 而省略时保持不变 |

`model` 与 `effort` 至少提供一个。

**使用场景**：让成员的模型匹配当前工作——任务比预期更难或成员反复失败时，换更强的模型或调高强度；常规、大批量的工作换更轻的模型或调低强度，以节省时间与额度。

**生效方式**：选择先落库，重启后保留。运行中的成员在下一轮开始前切换——正在进行的这一轮仍用原模型完成；未运行的成员下次启动即使用新模型。只有使用 CLI 自身登录的成员可以切换：用 `model_name` 拉起的成员，或已回退到团队模型池端点的成员会被拒绝。