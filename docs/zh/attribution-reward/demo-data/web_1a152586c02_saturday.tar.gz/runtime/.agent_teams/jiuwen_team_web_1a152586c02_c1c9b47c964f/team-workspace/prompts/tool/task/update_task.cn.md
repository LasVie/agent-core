---
kind: tool
name: update_task
language: cn
baseline_sha256: caed6230d18a36a9e0847bf26aaea0065bc6ffd84f684f40954b6be5c66faf59
evolved: false
updated_at: 1792382889856
---
更新任务内容、依赖、指派人或取消任务（仅 Leader 可用）。

## 使用场景

**更新任务内容：**
- 根据成员反馈调整任务范围或补充细节
- 传 title 和/或 content 修改。若任务正被某成员执行，任务归属保持不变，系统会通知该成员通过 view_task 重看最新内容后继续（不再取消或重置该成员）

**指派 / 改派任务：**
- 设置 assignee 为成员名称来指派任务
- 若目标任务当前无人认领，直接指派给该成员
- 若目标任务已被他人认领，视为改派：系统通知原成员停止该任务、把任务转交给新成员，不影响原成员的其它工作或正在执行的其它任务
- **每个成员同一时刻只能有一个进行中（in_progress）的任务**：若目标成员已有在做的任务，指派/改派会被拒绝，需等其完成后再派新任务

**添加依赖：**
- 传 add_blocked_by 和前置任务 ID 列表来添加新的依赖关系
- 若任务原为 pending，添加依赖后会自动变为 blocked，直到所有依赖完成

**取消任务：**
- 需求变更导致任务不再需要时，设置 status=cancelled
- 若任务正被某成员执行，系统会通知该成员停止（不再取消整个成员，其它工作不受影响）

**取消所有任务：**
- 目标根本性变更时，task_id="*" 配合 status=cancelled 全部重新规划
- 系统会逐一通知各正在执行的成员停止各自的任务；由人类成员认领的任务会被保留

{{update_task_verify_gate}}
## HITT 限制
任何由 role=human_agent 的人类成员持有（进行中：planning / in_progress / in_review）的任务，本工具**不允许** cancel、reassign 或修改标题/内容，无论该人类成员叫什么名字。人类成员锁定的任务必须由对应人类本人完成；Leader 的唯一干预方式是通过 `send_message(to="<对应的人类 member_name>")` 催促或沟通。这条规则不允许绕过，即使团队等待人类导致停滞也必须保持停滞。

## 示例

更新任务内容：
{"task_id": "task-1", "title": "新标题", "content": "新内容"}

指派任务：
{"task_id": "task-1", "assignee": "backend-dev"}

添加依赖：
{"task_id": "task-2", "add_blocked_by": ["task-1"]}

取消任务：
{"task_id": "task-1", "status": "cancelled"}

取消所有任务：
{"task_id": "*", "status": "cancelled"}