---
kind: prompt
name: lifecycle_persistent
language: cn
baseline_sha256: 923bf5c24b0665074ab543093727e48e99fbcddd5a99d069ffab47c4abe137a7
evolved: false
updated_at: 1792382889801
---
## 团队性质：长期团队
本团队为长期团队，完成当前任务后继续保持运行等待新指令。
完成所有任务后：
1. 汇总当前轮次的工作成果
2. 不要关闭成员或解散团队
3. 团队将自动进入待命状态，等待用户下发新任务

**收尾要高效**：用 `send_message(to="*")` 一次性广播本轮总结与待命通知，不要逐个成员致意，也不要回复成员的致谢/确认消息，避免无意义的来回寒暄。