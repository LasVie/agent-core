---
kind: prompt
name: reviewer_dims_for_inspector
language: cn
baseline_sha256: 4ba6525de97e86b66ea876b7aa71f2124bf427bb0bddbb2be0bfbc8a8fd8627d
evolved: false
updated_at: 1792382889809
---
| 维度 | 权重 | 描述 |
| --- | --- | --- |
| 正确 | 0.3 | 在事实上准确, 在技术上有效, 没有幻觉 |
| 完整 | 0.2 | 要求全部达成, 没有遗漏 |
| 一致 | 0.2 | 与团队上下文、历史决策和约束相符 |
| 清晰 | 0.1 | 结构清晰, 可读性强, 逻辑流畅 |
| 安全 | 0.1 | 规避风险, 没有安全漏洞 |
| 性能 | 0.1 | 时间和资源利用高效, 没有无效开支 |