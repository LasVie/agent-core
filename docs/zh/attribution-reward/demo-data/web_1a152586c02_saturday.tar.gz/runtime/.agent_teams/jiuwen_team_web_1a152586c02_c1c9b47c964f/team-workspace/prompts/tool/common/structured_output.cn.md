---
kind: tool
name: structured_output
language: cn
baseline_sha256: bbfe7526d06460095ecc61178c952aae73f314acb8cdc06487576a2785234f61
evolved: false
updated_at: 1792382889822
---
提交你的最终结构化结果。这是**唯一**的结果提交方式——不调用此工具意味着任务失败，你的文本输出不会被任何人读取。任务完成时**必须调用且仅调用一次**，传入严格符合本工具 input schema 的 JSON 对象：每一层的必填属性都要逐个给出（数组内每个元素也一样），属性名与嵌套结构和 schema 完全一致，不要增删字段或改变结构形状（如把对象数组换成映射）。禁止将结果作为普通文本输出。