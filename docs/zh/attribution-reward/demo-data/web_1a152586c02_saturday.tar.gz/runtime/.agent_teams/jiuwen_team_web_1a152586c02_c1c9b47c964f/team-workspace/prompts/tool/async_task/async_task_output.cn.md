---
kind: tool
name: async_task_output
language: cn
baseline_sha256: b475f129e5252e1c4aad8b64adac81b7f2136823a4fe852f594111ff9d27e2c4
evolved: false
updated_at: 1792382889820
---
取回某个后台异步任务的完整输出（或错误）。

## 何时使用
- 某后台任务的完整结果过大被写入磁盘时，注入给你的是摘要+路径——用本工具按 task_id 取回全文；
- 你想主动获取某个已完成任务的结果，而不等待自动回灌。

## 参数
- task_id：目标任务 id。
- block：是否阻塞等待终态（默认 false，立即返回当前状态）。
- timeout：block=true 时的最大等待毫秒数（默认 30000，上限 600000）。

## 注意
- 完成结果默认会**自动回灌**，通常无需主动调用本工具。
- block=true 会**占用你当前这一轮**直到任务终态或超时——仅在确需同步结果时使用，不要用它轮询。