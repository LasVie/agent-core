---
kind: tool
name: create_task_granularity
language: cn
baseline_sha256: a1061cee58b693e23cf2cbdde0adc55756c035c064074cb9a9c346693c15e9b6
evolved: false
updated_at: 1792382889827
---
## Tips

- 单个任务也用数组包裹 — tasks 始终是数组
- 描述目标，不描述步骤：content 写目标、验收标准、技术约束
- 单一负责人：每个任务对应一个可独立交付的成果
- 批内依赖只有一种写法：让下游任务 depends_on 上游；depended_by 专用于楔入已有 DAG

## 粒度范例

以"用户认证"为例：

- **太细**：拆成"设计 User 表"、"实现 POST /login"、"实现 JWT 签发"、"写单测"——每个都是执行步骤而非可交付成果，验收只能描述动作
- **合适**：一个任务"实现用户登录能力（注册 + 登录 + 会话保持）"，content 写清目标、验收标准（API 完成注册/登录/续期）、约束（bcrypt + JWT）。单人可独立交付，按 API 行为验收
- **太粗**：一个任务"开发整个用户模块"——覆盖过宽，多人并行还要二次拆分；单人做成本高、验收条目模糊