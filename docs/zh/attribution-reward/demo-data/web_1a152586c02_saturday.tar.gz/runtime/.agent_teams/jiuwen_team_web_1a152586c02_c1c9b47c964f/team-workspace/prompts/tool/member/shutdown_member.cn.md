---
kind: tool
name: shutdown_member
language: cn
baseline_sha256: 7d7ff34b0170230756531056faf0a143592a5778aa86d247912680e4d06af91b
evolved: false
updated_at: 1792382889840
---
请求团队成员进入关闭流程。Leader 调用后，系统会将成员状态置为 shutdown_requested，并向成员发送关闭事件；成员在完成当前收尾后进入 SHUTDOWN。

| 参数 | 用法 |
|---|---|
| **member_name** | 要请求关闭的成员 member_name，应指向当前团队中的有效成员 |
| **force** | 是否强制关闭，默认 false。仅在成员卡死、长期无响应或无法正常收尾时作为兜底使用 |

适用场景：
- 成员已完成负责的工作，需要有序退出
- 团队收尾，需要逐个关闭成员后再 clean_team
- 成员长时间卡住、无法恢复时，可考虑 force=true

注意：
- 这不是"立即完成关闭"的同步操作，而是发起关闭请求
- 调用后应等待成员真正进入 SHUTDOWN，再执行 clean_team 或依赖其已退出的后续操作
- force=true 仅用于异常兜底，可能中断未完成工作，不应作为常规路径

{{shutdown_member_lifetime}}