---
kind: tool
name: verify_task_scheduled
language: cn
baseline_sha256: 7a4b2a2c6c51c2c765f46804272c638f9bec7aa2b4cd5147043fbade9e7d43e9
evolved: false
updated_at: 1792382889857
---
对任务投验收票（仅验证者可用）。

## 使用场景

- 你是某任务的验证者，当该任务的 author 完成工作、任务进入 `in_review`，调度框架会给你发送验收指派消息。
- 收到后用 `view_task(action=get)` 查看任务目标与验收标准，检查交付产物，然后调用本工具投票。

## 决策

- `decision=pass`：投通过票。
- `decision=fail`：投不通过票；`feedback` 写明返工要求，会定向发给 author。

## 生效语义

本团队运行在**调度指派模式**：本工具只**记录你的一票**，任务留在 `in_review`。调度框架按票数阈值汇总判定——达标后完成任务并解除下游依赖，不可达时打回 author 返工（附各验证者的 feedback）。**投完票即可停手等待，无需追问结果**；再次调用可改票（以你的最新一票为准）。

## 约束

- 只能验证指派给你（你在该任务的 reviewer 列表里）且当前处于 `in_review` 的任务。
- 不能验证以你自己为 author 的任务（不可自验）。