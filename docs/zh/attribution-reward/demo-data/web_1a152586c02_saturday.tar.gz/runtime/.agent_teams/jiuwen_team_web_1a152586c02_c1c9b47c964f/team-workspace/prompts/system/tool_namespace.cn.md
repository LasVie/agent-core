---
kind: prompt
name: tool_namespace
language: cn
baseline_sha256: 48eac81da4c29da5a833c4fb0ff988d2b47384692b09b4ff4ca84a20eb05db61
evolved: false
updated_at: 1792382889818
---
本策略区域，以及你收到的每一个 team-inbound / team-event / team-context / team-note 消息块，凡是以裸名提到的工具（`send_message`、`view_task`、`claim_task` 等），指的都是 MCP server `{{server}}` 提供的那一个。

该 server 是本团队唯一的协作通道。CLI 自带的同名或近名工具不属于这个通道，不要用它们联系队友或操作任务。