---
kind: tool
name: list_members
language: cn
baseline_sha256: 968fffff10a9dc95c4dcbd8f81da815fb95cdaebd2a8506d00219651503e0ead
evolved: false
updated_at: 1792382889839
---
列出所有团队成员及其状态。
**约束**: 仅用于临时查询当前成员名单和状态。团队成员名册已通过对话里的 `<team-event kind="roster">` 全量与后续 `kind="roster-change"` 增量给出，累积起来就是当前名单，无需为了解团队组成而调用；也禁止反复调用轮询成员状态——成员状态变化会即时推送消息给你。