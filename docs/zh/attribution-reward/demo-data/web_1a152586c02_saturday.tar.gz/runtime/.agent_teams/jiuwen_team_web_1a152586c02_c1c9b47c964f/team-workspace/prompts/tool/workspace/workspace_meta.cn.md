---
kind: tool
name: workspace_meta
language: cn
baseline_sha256: 2ba3ca1c11e9206c90cea9cae2908391121bc578c440aba84562a1335e25f6ef
evolved: false
updated_at: 1792382889865
---
团队共享工作空间的元数据工具：**文件锁管理** 和 **版本历史查询**。多个成员协作修改共享文件时使用。

## 范围

本工具**不做**文件读写。共享工作空间以绝对路径暴露（见团队信息块「团队共享工作空间」的最终产物目录），文件读写请使用标准的 `read_file` / `write_file` / `glob` 等文件系统工具访问该目录下的路径。

## action

- **lock** — 获取文件独占锁（需 `path`）
- **unlock** — 释放文件锁（需 `path`）
- **locks** — 列出当前所有未过期的锁
- **history** — 查看文件的 git 版本历史（需 `path`），返回最近 10 条 commit（含 commit 哈希、作者、时间、消息）

## Lock 语义

- **独占**：同一文件同一时间只能有一个持有者
- **超时**：默认 300 秒自动过期，其他成员可在过期后回收
- **重入**：同一持有者对已持有的锁再次 `lock` 会刷新超时时间
- **协作性约定**：`write_file` 本身不会自动检查锁。写入共享文件前，成员应主动 `lock` → `write_file` → `unlock`，避免互相覆盖
- **获取失败**：返回 `Locked by {holder_name}`，说明当前持有者

## 何时使用

- 多成员并行修改团队共享产物目录下的共享文件时，写入前先 `lock`，写完后 `unlock`
- 需要查看共享文件历次修改记录时使用 `history`
- 协调冲突前用 `locks` 查看当前谁在持有什么

## 何时不使用

- 只读场景（无写冲突风险），不需要 lock
- 成员自己的 worktree 副本（`.agent_teams/worktrees/<slug>/`），由 worktree 隔离天然无冲突，不需要 lock