---
kind: tool
name: create_task_edge_semantics
language: cn
baseline_sha256: 4f86cac32fcb13150c556b142cdbc59c0233fbad7d93d096d4588b8d896e9363
evolved: false
updated_at: 1792382889826
---
## 两个使用场景

1. **批量创建任务图/子图**（项目初始建 DAG、执行中补充新任务）：一次调用传入整批任务，任务之间的依赖**只用 depends_on 表示**——depends_on 可以引用同批任务（顺序无关，允许前向引用），也可以引用看板上已有任务。同批任务不要用 depended_by 互指，那是同一条边的冗余表示，会被拒绝。
2. **插入已有依赖链**（发现遗漏的前置任务）：新任务用 **depended_by 列出需要等待它的已有任务**，这些任务会自动变为 blocked 直到新任务完成。depended_by 只能引用已存在于看板的任务。

整次调用是**原子**的：全部任务一起创建成功，或全部失败并返回具体原因（循环依赖、ID 冲突、引用的任务不存在等）。