---
kind: tool
name: builtin_model_usage
language: cn
baseline_sha256: d92ce596589ffd37f5aaa85a1d47db11378eaa153a4813418cd1f11570cf86a7
evolved: false
updated_at: 1792382889825
---
**内置模型**：部分 CLI 类型在 `<builtin_model_catalog>` 中声明了其自身登录（如订阅）可用的模型（见 `builtin_model` 参数）。用 `builtin_model` 选择模型，并可从该模型的 `efforts` 中选择 `effort`，使其与成员的工作量匹配——常规工作用更轻的模型或更低的强度，难题用更强的模型或更高的强度。只接受目录中的模型名与强度；两者都省略时由 CLI 使用其自身默认模型。该选择在重启后保留，之后可用 `set_member_model` 修改，无需重新拉起成员。