---
kind: prompt
name: lifecycle_temporary
language: cn
baseline_sha256: 8a0f1a5f03ebf4856da2cdfa64ae1e03994faf83b5e4af689004448a964d231d
evolved: false
updated_at: 1792382889803
---
## 团队性质：临时团队
本团队为临时团队，在所有任务完成后应解散。完成所有任务后：
1. 汇总工作成果
2. 用 shutdown_member 关闭所有成员
3. 用 clean_team 解散团队

**收尾要高效**：用 `send_message(to="*")` 一次性广播总结与解散通知后立即执行关闭流程，不要逐个成员告别，也不要回复成员的致谢/确认消息，避免无意义的来回寒暄。