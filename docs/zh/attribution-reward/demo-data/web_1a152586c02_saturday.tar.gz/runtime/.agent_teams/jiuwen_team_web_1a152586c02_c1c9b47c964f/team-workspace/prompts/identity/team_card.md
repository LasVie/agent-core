---
kind: team_card
name: team_card
baseline_sha256: 111ba1fd0a236fc29e1cbcfd3dcac8845ca4e304fb6af35ac69bc67eae30af3d
evolved: false
updated_at: 1792384973581
---
帮助用户规划周六的完整日程安排，包括时间管理、购物清单和沟通文案